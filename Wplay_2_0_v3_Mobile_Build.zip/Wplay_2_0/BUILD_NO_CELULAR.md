# Wplay 2.0 v3 - Compilação pelo celular

## O que foi preparado
Este projeto inclui um workflow do GitHub Actions para compilar o APK remotamente.
Você pode fazer tudo pelo celular usando o navegador.

## Caminho recomendado
1. Crie uma conta no GitHub.
2. Crie um repositório novo, por exemplo `wplay-android`.
3. Envie TODOS os arquivos e pastas que estão dentro desta pasta `Wplay_2_0`.
4. Abra a aba **Actions** do repositório.
5. Selecione **Build Wplay APK**.
6. Toque em **Run workflow**.
7. Aguarde o build terminar.
8. Abra o resultado do workflow e baixe o artefato `Wplay-debug-apk`.
9. Extraia o APK e instale no Android/TV Box.

## Observações
- O workflow é acionado manualmente.
- O APK gerado é de teste (debug).
- Para publicar na Google Play ou distribuir uma versão de produção, é necessário criar uma chave de assinatura e configurar um build release.
- Use somente servidores e conteúdos IPTV para os quais você tenha autorização.
