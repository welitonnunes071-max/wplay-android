# Wplay 2.0 Android / TV

Base de aplicativo Android horizontal para TV Box e Android TV, com identidade Wplay.

## Recursos da base
- Login por DNS/servidor + usuário + senha
- Integração Xtream Codes API para VOD e canais ao vivo
- Home horizontal com carrossel automático de destaques
- Cards de filmes com capas
- Player Media3/ExoPlayer
- Menu Início, Ao Vivo, Filmes, Séries, Favoritos e Configurações
- Configuração de idioma e limpeza de cache
- Conteúdo deve ser proveniente de serviços/IPTV que o usuário esteja autorizado a acessar.

## Observação
Esta é uma base de desenvolvimento. Para distribuição final, recomenda-se adicionar tratamento de erros de rede, HTTPS, armazenamento seguro de credenciais, EPG, temporadas/episódios, favoritos persistentes e testes com os formatos de stream do servidor autorizado.


## Wplay 2.0 v3
- Séries via `get_series`
- Temporadas/episódios via `get_series_info`
- Reprodução de episódios via Media3/ExoPlayer
- Minha Lista/Favoritos persistentes localmente
- Carrossel e catálogo de filmes mantidos
- Interface horizontal para Android/TV
- Use somente fontes e conteúdos para os quais você tenha autorização.
