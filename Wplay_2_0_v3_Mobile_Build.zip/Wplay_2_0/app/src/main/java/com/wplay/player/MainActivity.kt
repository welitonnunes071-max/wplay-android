package com.wplay.player

import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val handler = Handler(Looper.getMainLooper())
    private var player: ExoPlayer? = null
    private var base = ""
    private var user = ""
    private var pass = ""
    private var language = "Português"
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var movies = JSONArray()
    private var heroIndex = 0
    private var series = JSONArray()
    private var favoriteIds = mutableSetOf<String>()

    private val green = Color.rgb(57,255,136)
    private val bg = Color.rgb(5,8,6)
    private val panel = Color.rgb(15,21,17)
    private val text = Color.rgb(244,247,245)
    private val muted = Color.rgb(165,176,170)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        loadFavorites()
        buildLogin()
    }

    private fun loadFavorites() {
        favoriteIds = getPreferences(0).getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()
    }

    private fun saveFavorites() {
        getPreferences(0).edit().putStringSet("favorites", favoriteIds).apply()
    }

    private fun toggleFavorite(o: JSONObject) {
        val key = o.optString("stream_id").ifBlank { o.optString("series_id") }
        if (key.isBlank()) return
        if (!favoriteIds.add(key)) favoriteIds.remove(key)
        saveFavorites()
    }

    private fun isFavorite(o: JSONObject): Boolean {
        val key = o.optString("stream_id").ifBlank { o.optString("series_id") }
        return key.isNotBlank() && favoriteIds.contains(key)
    }

    private fun baseLayout(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
        setPadding(36, 24, 36, 24)
    }

    private fun label(value: String, size: Float = 18f) = TextView(this).apply {
        text = value; textSize = size; setTextColor(text); setPadding(0, 8, 0, 8)
    }

    private fun button(value: String, filled: Boolean = false) = Button(this).apply {
        text = value; isAllCaps = false; textSize = 15f
        setTextColor(if (filled) Color.BLACK else text)
        if (filled) setBackgroundColor(green) else setBackgroundColor(panel)
        minHeight = 48
    }

    private fun field(hint: String, password: Boolean = false) = EditText(this).apply {
        this.hint = hint; setSingleLine(true); setTextColor(text); setHintTextColor(muted)
        setPadding(18, 0, 18, 0); setBackgroundColor(panel)
        if (password) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    private fun buildLogin(message: String = "") {
        root = baseLayout()
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(80, 20, 80, 20) }
        val logo = ImageView(this).apply { setImageResource(R.drawable.wplay_logo); adjustViewBounds = true; scaleType = ImageView.ScaleType.CENTER_INSIDE }
        box.addView(logo, LinearLayout.LayoutParams(-1, 190))
        box.addView(label("Conecte seu serviço IPTV", 22f))
        val dns = field("DNS / Servidor  •  http://servidor:porta")
        val u = field("Usuário")
        val p = field("Senha", true)
        box.addView(dns, lp(0, 56)); box.addView(u, lp(0, 56)); box.addView(p, lp(0, 56))
        val enter = button("Entrar", true)
        box.addView(enter, lp(0, 58))
        if (message.isNotBlank()) box.addView(label(message, 15f))
        enter.setOnClickListener {
            base = dns.text.toString().trim().trimEnd('/')
            user = u.text.toString().trim(); pass = p.text.toString()
            if (base.isBlank() || user.isBlank() || pass.isBlank()) { Toast.makeText(this, "Preencha DNS, usuário e senha.", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            loadHome()
        }
        scroll.addView(box); root.addView(scroll); setContentView(root)
    }

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(if (w == 0) -1 else w, h).apply { setMargins(0, 7, 0, 7) }

    private fun loadHome() {
        root = baseLayout()
        val nav = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val brand = label("Wplay", 28f).apply { setTextColor(green); setTypeface(null, android.graphics.Typeface.BOLD) }
        nav.addView(brand, LinearLayout.LayoutParams(130, 60))
        listOf("Início", "Ao Vivo", "Filmes", "Séries", "Favoritos", "Configurações").forEach { item ->
            val b = button(item)
            nav.addView(b, LinearLayout.LayoutParams(0, 52, 1f))
            b.setOnClickListener { when(item) { "Filmes" -> showMovies(); "Ao Vivo" -> showLive(); "Séries" -> showSeries(); "Favoritos" -> showFavorites(); "Configurações" -> showSettings(); else -> loadHome() } }
        }
        root.addView(nav)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        buildHomeContent()
    }

    private fun buildHomeContent() {
        content.removeAllViews()
        val hero = FrameLayout(this).apply { setBackgroundColor(panel) }
        val heroImage = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0.72f }
        val heroText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(35, 25, 35, 20); gravity = Gravity.BOTTOM }
        val title = label("Carregando destaques…", 30f).apply { setTypeface(null, android.graphics.Typeface.BOLD) }
        val sub = label("Filmes e séries do seu catálogo", 16f)
        val watch = button("▶  Assistir", true)
        heroText.addView(title); heroText.addView(sub); heroText.addView(watch, LinearLayout.LayoutParams(180, 52))
        hero.addView(heroImage, FrameLayout.LayoutParams(-1, 310)); hero.addView(heroText, FrameLayout.LayoutParams(-1, 310))
        content.addView(hero, lp(0, 310))
        val status = label("Carregando catálogo…", 16f); content.addView(status)
        scope.launch {
            try {
                movies = getJsonArray("$base/player_api.php?username=${enc(user)}&password=${enc(pass)}&action=get_vod_streams")
                status.text = "${movies.length()} filmes disponíveis"
                setupHero(heroImage, title, sub, watch)
                addMovieRow("Filmes em destaque", movies, 12)
                addMovieRow("Todos os filmes", movies, movies.length())
            } catch (e: Exception) { status.text = "Não foi possível carregar o catálogo. Verifique a conexão." }
        }
    }

    private fun setupHero(image: ImageView, title: TextView, sub: TextView, watch: Button) {
        if (movies.length() == 0) return
        fun show(i: Int) {
            val o = movies.optJSONObject(i) ?: return
            title.text = o.optString("name", "Filme")
            sub.text = o.optString("plot", "").ifBlank { "Filme disponível no seu catálogo" }.take(150)
            scope.launch { loadImage(o.optString("stream_icon"))?.let { image.setImageBitmap(it) } }
            watch.setOnClickListener { playMovie(o) }
        }
        show(heroIndex)
        handler.postDelayed(object : Runnable { override fun run() { if (movies.length() > 0) { heroIndex = (heroIndex + 1) % movies.length(); show(heroIndex) }; handler.postDelayed(this, 6500) } }, 6500)
    }

    private fun addMovieRow(titleText: String, arr: JSONArray, count: Int) {
        if (arr.length() == 0) return
        content.addView(label(titleText, 22f).apply { setPadding(5, 18, 0, 10) })
        val horizontal = HorizontalScrollView(this)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val max = minOf(count, arr.length())
        for (i in 0 until max) {
            val o = arr.optJSONObject(i) ?: continue
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0,0,12,0); isFocusable = true; isClickable = true }
            val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(panel) }
            card.addView(img, LinearLayout.LayoutParams(170, 245))
            card.addView(label(o.optString("name", "Filme").take(24), 14f), LinearLayout.LayoutParams(170, 45))
            val fav = button(if (isFavorite(o)) "★ Favorito" else "☆ Minha lista")
            fav.setOnClickListener { toggleFavorite(o); fav.text = if (isFavorite(o)) "★ Favorito" else "☆ Minha lista" }
            card.addView(fav, LinearLayout.LayoutParams(170, 44))
            card.setOnClickListener { playMovie(o) }
            row.addView(card)
            val icon = o.optString("stream_icon")
            if (icon.isNotBlank()) scope.launch { loadImage(icon)?.let { img.setImageBitmap(it) } }
        }
        horizontal.addView(row); content.addView(horizontal, lp(0, 305))
    }

    private fun showMovies() {
        content.removeAllViews(); content.addView(label("Filmes", 28f))
        if (movies.length() == 0) { content.addView(label("Carregando…")); scope.launch { movies = getJsonArray("$base/player_api.php?username=${enc(user)}&password=${enc(pass)}&action=get_vod_streams"); showMovies() }; return }
        addMovieRow("Catálogo", movies, movies.length())
    }

    private fun showLive() {
        content.removeAllViews(); content.addView(label("Ao Vivo", 28f)); content.addView(label("Canais carregados do seu servidor", 16f))
        scope.launch { try { val arr=getJsonArray("$base/player_api.php?username=${enc(user)}&password=${enc(pass)}&action=get_live_streams"); val row=HorizontalScrollView(this@MainActivity); val box=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL}; for(i in 0 until arr.length()){ val o=arr.optJSONObject(i)?:continue; val b=button(o.optString("name","Canal")); b.setOnClickListener{ playLive(o) }; box.addView(b,LinearLayout.LayoutParams(230,70)); }; row.addView(box); content.addView(row,lp(0,100)) } catch(e:Exception){content.addView(label("Não foi possível carregar os canais."))} }
    }

    private fun showSeries() {
        content.removeAllViews()
        content.addView(label("Séries", 28f))
        scope.launch {
            try {
                series = getJsonArray("$base/player_api.php?username=${enc(user)}&password=${enc(pass)}&action=get_series")
                addSeriesRow("Todas as séries", series, series.length())
            } catch (e: Exception) {
                content.addView(label("Não foi possível carregar as séries."))
            }
        }
    }

    private fun addSeriesRow(titleText: String, arr: JSONArray, count: Int) {
        if (arr.length() == 0) { content.addView(label("Nenhuma série encontrada.")); return }
        content.addView(label(titleText, 22f).apply { setPadding(5, 18, 0, 10) })
        val horizontal = HorizontalScrollView(this)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0 until minOf(count, arr.length())) {
            val o = arr.optJSONObject(i) ?: continue
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0,0,12,0); isFocusable = true; isClickable = true }
            val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(panel) }
            card.addView(img, LinearLayout.LayoutParams(190, 270))
            card.addView(label(o.optString("name", "Série").take(24), 14f), LinearLayout.LayoutParams(190, 45))
            val fav = button(if (isFavorite(o)) "★ Favorito" else "☆ Minha lista")
            fav.setOnClickListener { toggleFavorite(o); fav.text = if (isFavorite(o)) "★ Favorito" else "☆ Minha lista" }
            card.addView(fav, LinearLayout.LayoutParams(190, 44))
            card.setOnClickListener { showSeriesInfo(o) }
            row.addView(card)
            val icon = o.optString("cover")
            if (icon.isNotBlank()) scope.launch { loadImage(icon)?.let { img.setImageBitmap(it) } }
        }
        horizontal.addView(row)
        content.addView(horizontal, lp(0, 365))
    }

    private fun showSeriesInfo(o: JSONObject) {
        content.removeAllViews()
        content.addView(label(o.optString("name", "Série"), 28f))
        content.addView(label(o.optString("plot", "Escolha uma temporada e episódio."), 16f))
        val back = button("‹ Voltar")
        back.setOnClickListener { showSeries() }
        content.addView(back, lp(220, 52))
        scope.launch {
            try {
                val id = o.optString("series_id")
                val info = getJsonObject("$base/player_api.php?username=${enc(user)}&password=${enc(pass)}&action=get_series_info&series_id=${enc(id)}")
                val seasons = info.optJSONArray("episodes") ?: JSONArray()
                if (seasons.length() == 0) { content.addView(label("Nenhum episódio disponível.")); return@launch }
                for (seasonIndex in 0 until seasons.length()) {
                    val season = seasons.optJSONArray(seasonIndex) ?: continue
                    content.addView(label("Temporada ${seasonIndex + 1}", 22f))
                    for (j in 0 until season.length()) {
                        val ep = season.optJSONObject(j) ?: continue
                        val title = ep.optString("title", "Episódio ${j + 1}")
                        val b = button("▶  $title")
                        b.setOnClickListener { playEpisode(ep, o.optString("name", "Série")) }
                        content.addView(b, lp(0, 58))
                    }
                }
            } catch (e: Exception) {
                content.addView(label("Não foi possível carregar os episódios."))
            }
        }
    }

    private fun showFavorites() {
        content.removeAllViews()
        content.addView(label("Minha Lista", 28f))
        val favMovies = JSONArray()
        for (i in 0 until movies.length()) {
            val o = movies.optJSONObject(i) ?: continue
            if (isFavorite(o)) favMovies.put(o)
        }
        if (favMovies.length() > 0) addMovieRow("Filmes", favMovies, favMovies.length()) else content.addView(label("Nenhum filme favorito ainda."))
        val favSeries = JSONArray()
        for (i in 0 until series.length()) {
            val o = series.optJSONObject(i) ?: continue
            if (isFavorite(o)) favSeries.put(o)
        }
        if (favSeries.length() > 0) addSeriesRow("Séries", favSeries, favSeries.length())
    }

    private fun showSettings() {
        content.removeAllViews(); content.addView(label("Configurações",28f))
        val lang = button("Idioma: $language"); lang.setOnClickListener { language = if(language=="Português") "English" else if(language=="English") "Español" else "Português"; lang.text="Idioma: $language" }; content.addView(lang,lp(0,60))
        val clear = button("Limpar cache"); clear.setOnClickListener { getPreferences(0).edit().clear().apply(); Toast.makeText(this,"Cache local limpo.",Toast.LENGTH_SHORT).show() }; content.addView(clear,lp(0,60))
        val logout = button("Sair da conta"); logout.setOnClickListener { player?.release(); buildLogin() }; content.addView(logout,lp(0,60))
        content.addView(label("Wplay 2.0 • Player Media3",15f))
    }

    private fun playMovie(o: JSONObject) {
        val id=o.optString("stream_id"); val ext=o.optString("container_extension","mp4").ifBlank{"mp4"}
        val url="$base/movie/${enc(user)}/${enc(pass)}/$id.$ext"; play(url, o.optString("name","Filme"))
    }
    private fun playLive(o: JSONObject) { val id=o.optString("stream_id"); val url="$base/live/${enc(user)}/${enc(pass)}/$id"; play(url,o.optString("name","Canal")) }

    private fun play(url:String, title:String) {
        player?.release()
        player = ExoPlayer.Builder(this).build()
        val pv = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK)
            useController = true
            controllerShowTimeoutMs = 3500
            keepScreenOn = true
        }
        val frame = FrameLayout(this)
        frame.setBackgroundColor(Color.BLACK)
        frame.addView(pv, FrameLayout.LayoutParams(-1, -1))
        val back = button("‹  Voltar")
        back.setOnClickListener { player?.release(); loadHome() }
        frame.addView(back, FrameLayout.LayoutParams(150, 55).apply { leftMargin = 20; topMargin = 20 })
        val titleView = label(title, 18f).apply {
            setBackgroundColor(Color.argb(170, 0, 0, 0))
            setPadding(18, 10, 18, 10)
        }
        frame.addView(titleView, FrameLayout.LayoutParams(-2, 55).apply { gravity = Gravity.TOP or Gravity.END; rightMargin = 20; topMargin = 20 })
        setContentView(frame)
        pv.player = player
        player?.setMediaItem(MediaItem.fromUri(url))
        player?.prepare()
        player?.playWhenReady = true
    }

    private fun playEpisode(ep: JSONObject, seriesName: String) {
        val id = ep.optString("id").ifBlank { ep.optString("episode_id") }
        val ext = ep.optString("container_extension", "mp4").ifBlank { "mp4" }
        val url = "$base/series/${enc(user)}/${enc(pass)}/$id.$ext"
        play(url, "$seriesName • ${ep.optString("title", "Episódio")}")
    }

    private suspend fun getJsonObject(url:String):JSONObject = withContext(Dispatchers.IO) { JSONObject(URL(url).readText()) }
    private suspend fun getJsonArray(url:String):JSONArray = withContext(Dispatchers.IO) { JSONArray(URL(url).readText()) }
    private suspend fun loadImage(url:String) = withContext(Dispatchers.IO) { if(url.isBlank()) null else try { URL(url).openStream().use{BitmapFactory.decodeStream(it)} } catch(_:Exception){null} }
    private fun enc(v:String)=URLEncoder.encode(v,"UTF-8")
    override fun onDestroy(){ handler.removeCallbacksAndMessages(null); player?.release(); scope.cancel(); super.onDestroy() }
}
